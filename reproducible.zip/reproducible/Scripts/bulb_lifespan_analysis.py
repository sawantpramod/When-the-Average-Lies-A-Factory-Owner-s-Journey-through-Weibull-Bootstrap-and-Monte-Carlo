"""
Bulb Lifespan Dataset Analysis
------------------------------
Phase-wise reproducible analysis of bulb lifespans.
Saves figures to output/figures and prints key statistics.
"""

import argparse
import io
import os
import urllib.error
import urllib.request

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats


# ----------------------------------------------------------------------
# Data sources
# ----------------------------------------------------------------------
DATA_URLS = [
    "https://gist.githubusercontent.com/epogrebnyak/7933e16c0ad215742c4c104be4fbdeb1/"
    "raw/c932bc5b6aa6317770c4cbf43eb591511fec08f9/lamps.csv",
    "https://gist.githubusercontent.com/epogrebnyak/7933e16c0ad215742c4c104be4fbdeb1/"
    "raw/lamps.csv",
    "https://github.com/AllenDowney/SurvivalAnalysisPython/raw/master/lamps.csv",
]


def load_dataframe(data_path=None):
    if data_path:
        print(f"Loading data from local file: {data_path}")
        return pd.read_csv(data_path, index_col=0)

    last_error = None
    for url in DATA_URLS:
        try:
            print(f"Trying URL: {url}")
            with urllib.request.urlopen(url, timeout=15) as resp:
                raw = resp.read().decode("utf-8")
            df = pd.read_csv(io.StringIO(raw), index_col=0)
            print(f"  -> OK  ({len(df)} rows)")
            return df
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            print(f"  -> failed: {exc}")
            last_error = exc
        except Exception as exc:
            print(f"  -> failed: {exc}")
            last_error = exc

    raise RuntimeError(
        "Could not download the lamps dataset from any known URL.\n"
        "Please save the CSV locally (e.g. lamps.csv) and run:\n"
        "    python Scripts\\bulb_lifespan_analysis.py --data lamps.csv"
    ) from last_error


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def save_fig(fig, outdir, name):
    path = os.path.join(outdir, name)
    fig.savefig(path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"  [saved] {path}")


# ----------------------------------------------------------------------
# Parametric-bootstrap KS test for a fitted Weibull
# ----------------------------------------------------------------------
def parametric_bootstrap_ks(shape, scale, n, ks_obs, n_boot=2000, seed=42):
    
    rng = np.random.default_rng(seed)
    boot_ks = np.empty(n_boot)
    for i in range(n_boot):
        sample = stats.weibull_min.rvs(shape, scale=scale, size=n, random_state=rng)
        k_b, _, s_b = stats.weibull_min.fit(sample, floc=0)
        ks_b, _ = stats.kstest(sample, 'weibull_min', args=(k_b, 0, s_b))
        boot_ks[i] = ks_b
    return float(np.mean(boot_ks >= ks_obs))


# ----------------------------------------------------------------------
# Main analysis
# ----------------------------------------------------------------------
def main(data_path=None, outdir="output/figures"):
    ensure_dir(outdir)
    print("=" * 70)
    print("BULB LIFESPAN DATASET ANALYSIS")
    print("=" * 70)

# ==================================================================
# PHASE 1 — Data Loading & Descriptive Statistics
# ==================================================================
    print("\n--- PHASE 1: Data Loading & Descriptive Statistics ---")
    df = load_dataframe(data_path)

# ------------------------------------------------------------------
# Describe the raw structure of the file.
# ------------------------------------------------------------------
    print("\n  About the raw data (lamps.csv):")
    print(f"    Columns: {list(df.columns)}  (i=index, h=hours, f=frequency, K=count remaining)")
    print(f"    Rows: {len(df)} distinct hour-values")
    print(f"    Total bulbs (sum of 'f'): {int(df['f'].sum())}")
    print(f"    Distinct hour-values: {df['h'].nunique()} "
          f"(min {df['h'].min()} h, max {df['h'].max()} h)")
    print(f"    Repeated hour-values (ties): "
          f"{int((df['f'] > 1).sum())} rows have f > 1")
    on_grid = bool((df['h'] % 12 == 0).all())
    print(f"    All recorded times are multiples of 12 h: {on_grid} "
          f"(the source describes checks every 12 hours)")
    print(f"    Survivors after the last failure (K): {int(df['K'].iloc[-1])} "
          f"(0 means every bulb failed; no censoring)")

    lifespans = np.repeat(df['h'].values, df['f'].values)
    print(f"\nTotal bulbs: {len(lifespans)}")
    print(f"Mean lifespan: {np.mean(lifespans):.2f} hours")
    print(f"Std deviation (population, divisor n):     {np.std(lifespans):.2f} hours")
    print(f"Std deviation (sample, divisor n - 1):     {np.std(lifespans, ddof=1):.2f} hours")
    print(f"Median lifespan: {np.median(lifespans):.2f} hours")
    print(f"Min / Max: {lifespans.min()} / {lifespans.max()} hours")

# ==================================================================
# PHASE 2 — Visualizing the Data First
# ==================================================================
    print("\n--- PHASE 2: Visualizing the Data ---")
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(lifespans, bins=15, edgecolor='black', alpha=0.7)
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Frequency')
    ax.set_title('Distribution of Bulb Lifespans (Raw Data)')
    save_fig(fig, outdir, "phase2_histogram_raw.png")

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.boxplot(lifespans, orientation='horizontal')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_title('Box Plot of Bulb Lifespans')
    save_fig(fig, outdir, "phase2_boxplot.png")

# ==================================================================
# PHASE 3 — Outlier Detection (IQR Method)
# ==================================================================
    print("\n--- PHASE 3: Outlier Detection (IQR) ---")
    Q1 = np.percentile(lifespans, 25)
    Q3 = np.percentile(lifespans, 75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = lifespans[(lifespans < lower_bound) | (lifespans > upper_bound)]
    print(f"Q1 = {Q1:.2f}, Q3 = {Q3:.2f}, IQR = {IQR:.2f}")
    print(f"Normal range: [{lower_bound:.2f}, {upper_bound:.2f}] hours")
    print(f"Outliers detected: {outliers}")

# ==================================================================
# PHASE 4 — Fit the Exponential (Baseline Model)
# ==================================================================
    print("\n--- PHASE 4: Exponential Baseline Model ---")
    lambda_mle = 1 / np.mean(lifespans)
    print(f"MLE estimate of failure rate (λ): {lambda_mle:.6f} per hour")
    print(f"Mean time to failure (MTTF): {1/lambda_mle:.2f} hours")

    x = np.linspace(0, max(lifespans), 1000)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(lifespans, bins=15, density=True, alpha=0.6, label='Observed')
    ax.plot(x, stats.expon.pdf(x, scale=1/lambda_mle), 'r-', label='Fitted Exponential')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Bulb Lifespan Distribution vs Fitted Exponential')
    ax.legend()
    save_fig(fig, outdir, "phase4_hist_exponential.png")

    sorted_data = np.sort(lifespans)
    ecdf = np.arange(1, len(sorted_data) + 1) / len(sorted_data)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.step(sorted_data, ecdf, where='post', label='Empirical CDF')
    ax.plot(x, stats.expon.cdf(x, scale=1/lambda_mle), 'r-', label='Fitted Exponential CDF')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Cumulative Probability')
    ax.set_title('Empirical vs Fitted CDF')
    ax.legend()
    save_fig(fig, outdir, "phase4_ecdf.png")

    fig, ax = plt.subplots(figsize=(8, 8))
    stats.probplot(lifespans, dist="expon", plot=ax)
    ax.set_title('Q-Q Plot: Bulb Lifespans vs Exponential')
    save_fig(fig, outdir, "phase4_qq_exponential.png")

# ==================================================================
# PHASE 5 — Goodness-of-Fit Test (Reject Exponential)
# ==================================================================
    print("\n--- PHASE 5: Goodness-of-Fit Test vs Exponential ---")
    ks_stat, ks_p = stats.kstest(lifespans, 'expon', args=(0, 1/lambda_mle))
    print(f"KS statistic = {ks_stat:.4f}")
    print(f"KS p-value   = {ks_p:.4f}  ({ks_p:.2e})")
    print(f"Fitted Exponential CDF at the first failure ({lifespans.min()} h): "
          f"{stats.expon.cdf(lifespans.min(), scale=1/lambda_mle):.3f} "
          f"(empirical CDF just before it: 0)")

# ==================================================================
# PHASE 6 — Fit the Weibull (Better Model) & Compare
# ==================================================================
    print("\n--- PHASE 6: Weibull Model & Comparison ---")
    shape, loc, scale = stats.weibull_min.fit(lifespans, floc=0)
    print(f"Weibull shape (k)  = {shape:.4f}")
    print(f"Weibull scale (η)  = {scale:.4f}")
    print(f"Weibull location   = {loc:.4f}")

    ll_exp = np.sum(stats.expon.logpdf(lifespans, scale=1/lambda_mle))
    ll_weibull = np.sum(stats.weibull_min.logpdf(lifespans, shape, loc=0, scale=scale))

    aic_exp = 2*1 - 2*ll_exp
    aic_weibull = 2*2 - 2*ll_weibull
    bic_exp = 1*np.log(len(lifespans)) - 2*ll_exp
    bic_weibull = 2*np.log(len(lifespans)) - 2*ll_weibull

    print(f"\nLog-likelihood Exponential: {ll_exp:.2f}")
    print(f"Log-likelihood Weibull:     {ll_weibull:.2f}")
    print(f"AIC Exponential: {aic_exp:.2f}")
    print(f"AIC Weibull:     {aic_weibull:.2f}")
    print(f"BIC Exponential: {bic_exp:.2f}")
    print(f"BIC Weibull:     {bic_weibull:.2f}")

    ks_w_stat, ks_w_p = stats.kstest(lifespans, 'weibull_min', args=(shape, 0, scale))
    print(f"\nWeibull KS statistic = {ks_w_stat:.4f}")
    print(f"Weibull KS p-value   = {ks_w_p:.4f}")

# ------------------------------------------------------------------
# Likelihood-ratio test: the Exponential is nested in the Weibull
# (k = 1), so df = 1 (one extra parameter).
# ------------------------------------------------------------------
    lrt_stat = 2.0 * (ll_weibull - ll_exp)
    p_lrt = stats.chi2.sf(lrt_stat, df=1)
    print(f"\nLikelihood-ratio test (Weibull vs Exponential, df=1):")
    print(f"  LRT statistic = {lrt_stat:.2f}")
    print(f"  p-value       = {p_lrt:.3e}")
    if p_lrt < 0.0001:
        print("  -> Exponential formally rejected in favour of Weibull (p < 0.0001).")

# ------------------------------------------------------------------
# The KS p-value above is optimistically biased because (k, scale)
# were estimated from the same sample.  Correct it with a
# parametric bootstrap.
# ------------------------------------------------------------------
    print("\nParametric-bootstrap KS correction (2000 resamples)...")
    ks_w_p_corrected = parametric_bootstrap_ks(
        shape, scale, n=len(lifespans), ks_obs=ks_w_stat,
        n_boot=2000, seed=42
    )
    print(f"  Corrected Weibull KS p-value = {ks_w_p_corrected:.4f}")
    if ks_w_p_corrected > 0.05:
        print("  -> Weibull still not rejected after correction.")
    else:
        print("  -> After correction, Weibull is also rejected; "
              "consider Lognormal / Gamma (Phase 6b).")

# ==================================================================
# PHASE 6b — Alternative distributions
# Compare Weibull against Lognormal and Gamma; also fit a free-
# location 3-parameter Weibull.
# ==================================================================
    print("\n--- PHASE 6b: Alternative Distribution Comparison ---")

# Each entry: (label, loglik, k_params, ks_p, notes)
    comparison = []
    comparison.append(("Exponential",  ll_exp,     1, ks_p,       "baseline"))
    comparison.append(("Weibull (2p)", ll_weibull, 2, ks_w_p,     "floc=0"))
# Weibull KS p is the *uncorrected* one; note it separately below.

# Lognormal (floc=0 for consistency with a lifetime dist.)
    ln_shape, ln_loc, ln_scale = stats.lognorm.fit(lifespans, floc=0)
    ll_ln = np.sum(stats.lognorm.logpdf(lifespans, ln_shape, loc=0, scale=ln_scale))
    ks_ln_stat, ks_ln_p = stats.kstest(
        lifespans, 'lognorm', args=(ln_shape, 0, ln_scale)
    )
    comparison.append(("Lognormal",   ll_ln, 2, ks_ln_p, f"σ={ln_shape:.3f}, "
                                                         f"scale={ln_scale:.1f}"))

# Gamma (floc=0)
    g_shape, g_loc, g_scale = stats.gamma.fit(lifespans, floc=0)
    ll_g = np.sum(stats.gamma.logpdf(lifespans, g_shape, loc=0, scale=g_scale))
    ks_g_stat, ks_g_p = stats.kstest(
        lifespans, 'gamma', args=(g_shape, 0, g_scale)
    )
    comparison.append(("Gamma",       ll_g, 2, ks_g_p, f"α={g_shape:.3f}, "
                                                      f"scale={g_scale:.1f}"))

# 3-parameter Weibull (free location)
    shape3, loc3, scale3 = stats.weibull_min.fit(lifespans)
    ll_w3 = np.sum(stats.weibull_min.logpdf(lifespans, shape3, loc3, scale3))
    ks_w3_stat, ks_w3_p = stats.kstest(
        lifespans, 'weibull_min', args=(shape3, loc3, scale3)
    )
    comparison.append(("Weibull (3p)", ll_w3, 3, ks_w3_p,
                       f"k={shape3:.3f}, loc={loc3:.1f}, scale={scale3:.1f}"))

    n = len(lifespans)
    print(f"\n{'Model':<15}{'k':>3}{'LogLik':>12}{'AIC':>10}{'BIC':>10}"
          f"{'KS p':>10}   Notes")
    print("-" * 90)
    for name, ll, kpar, ksp, note in comparison:
        aic = 2 * kpar - 2 * ll
        bic = kpar * np.log(n) - 2 * ll
        print(f"{name:<15}{kpar:>3}{ll:>12.2f}{aic:>10.2f}{bic:>10.2f}"
              f"{ksp:>10.4f}   {note}")

# AIC / BIC differences and Akaike weights for the two-parameter models
    print("\nNote: KS p-values in the table are not corrected for estimated "
          "parameters (the corrected Weibull value is printed above).")
    two_param = {name: (ll, kpar) for name, ll, kpar, _, _ in comparison
                 if name in ("Weibull (2p)", "Lognormal", "Gamma")}
    aics = {name: 2 * kpar - 2 * ll for name, (ll, kpar) in two_param.items()}
    bics = {name: kpar * np.log(n) - 2 * ll for name, (ll, kpar) in two_param.items()}
    best_aic = min(aics.values())
    weights = {name: np.exp(-(a - best_aic) / 2) for name, a in aics.items()}
    wsum = sum(weights.values())
    print("\nTwo-parameter models: differences from the lowest AIC / BIC, and Akaike weights")
    for name in two_param:
        print(f"  {name:<14} dAIC = {aics[name]-best_aic:5.2f}   "
              f"dBIC = {bics[name]-min(bics.values()):5.2f}   weight = {weights[name]/wsum:.3f}")

# Free-location check
    print(f"\nFree-location Weibull check:")
    print(f"  2p:  k={shape:.4f}, η={scale:.4f}, AIC={aic_weibull:.2f}")
    print(f"  3p:  k={shape3:.4f}, loc={loc3:.4f}, η={scale3:.4f}, AIC={2*3-2*ll_w3:.2f}")
    aic_w3 = 2 * 3 - 2 * ll_w3
    bic_w3 = 3 * np.log(n) - 2 * ll_w3
    print(f"  AIC difference (2p - 3p) = {aic_weibull - aic_w3:.2f}   "
          f"BIC difference (2p - 3p) = {bic_weibull - bic_w3:.2f}")

# ==================================================================
# PHASE 7 — Bootstrap Confidence Interval (Weibull parameters)
# ==================================================================
    print("\n--- PHASE 7: Bootstrap Confidence Intervals ---")
    np.random.seed(42)
    n_bootstrap = 10_000
    bootstrap_shapes = []
    bootstrap_scales = []
    for _ in range(n_bootstrap):
        sample = np.random.choice(lifespans, size=len(lifespans), replace=True)
        k_b, _, s_b = stats.weibull_min.fit(sample, floc=0)
        bootstrap_shapes.append(k_b)
        bootstrap_scales.append(s_b)

    shape_lower, shape_upper = np.percentile(bootstrap_shapes, [2.5, 97.5])
    scale_lower, scale_upper = np.percentile(bootstrap_scales, [2.5, 97.5])
    print(f"95% CI for shape (k): [{shape_lower:.3f}, {shape_upper:.3f}]")
    print(f"95% CI for scale (η): [{scale_lower:.1f}, {scale_upper:.1f}]")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(bootstrap_shapes, bins=50, density=True, alpha=0.7, edgecolor='black')
    ax.axvline(shape, color='red', linestyle='--', label=f'Point estimate k = {shape:.3f}')
    ax.axvline(shape_lower, color='green', linestyle=':', label=f'2.5% = {shape_lower:.3f}')
    ax.axvline(shape_upper, color='green', linestyle=':', label=f'97.5% = {shape_upper:.3f}')
    ax.set_xlabel('Weibull shape (k)')
    ax.set_ylabel('Density')
    ax.set_title('Bootstrap Distribution of Weibull Shape Parameter')
    ax.legend()
    save_fig(fig, outdir, "phase7_bootstrap_shape.png")

# ==================================================================
# PHASE 8 — Monte Carlo Simulation (Using Weibull)
# ==================================================================
    print("\n--- PHASE 8: Monte Carlo Simulation ---")
# NOTE: 500 h is illustrative, not a warranty length taken from the
# dataset.  It lies below the minimum observed lifespan (840 h), so
# this number is a model-based extrapolation.
    warranty_hours = 500
    simulated_lifespans = stats.weibull_min.rvs(shape, loc=0, scale=scale, size=100_000)
    prob_fail = np.mean(simulated_lifespans < warranty_hours)
    print(f"P(failure before {warranty_hours} h) = {prob_fail:.2%}")
    print(f"  [Note: {warranty_hours} h is illustrative and lies below the "
          f"minimum observed lifespan ({lifespans.min()} h).]")

    pred_lower, pred_upper = np.percentile(simulated_lifespans, [2.5, 97.5])
    print(f"95% prediction interval (parameter-fixed): "
          f"[{pred_lower:.1f}, {pred_upper:.1f}] hours")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(simulated_lifespans, bins=100, density=True, alpha=0.6, label='Simulated (Weibull)')
    ax.axvline(warranty_hours, color='red', linestyle='--', label=f'Warranty = {warranty_hours}h')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Monte Carlo Simulation of 100,000 Bulbs (Weibull model)')
    ax.legend()
    save_fig(fig, outdir, "phase8_monte_carlo.png")

# ==================================================================
# PHASE 8b — Two-stage Monte Carlo (propagates parameter
# uncertainty).  Draw (k, scale) from the Phase 7 bootstrap, then draw
# one lifespan from that specific Weibull.
# ==================================================================
    print("\n--- PHASE 8b: Two-Stage Monte Carlo (with parameter uncertainty) ---")
    rng = np.random.default_rng(seed=7)
    idx = rng.integers(0, len(bootstrap_shapes), size=100_000)
    k_arr = np.asarray(bootstrap_shapes)[idx]
    lam_arr = np.asarray(bootstrap_scales)[idx]
# Inverse-CDF sampling from Weibull: X = λ (-ln U)^(1/k)
    U = rng.uniform(size=100_000)
    two_stage_lifespans = lam_arr * (-np.log(U)) ** (1.0 / k_arr)

    prob_fail_2s = np.mean(two_stage_lifespans < warranty_hours)
    p2_lower, p2_upper = np.percentile(two_stage_lifespans, [2.5, 97.5])
    print(f"P(failure before {warranty_hours} h) = {prob_fail_2s:.2%}")
    print(f"95% prediction interval (parameter-propagated): "
          f"[{p2_lower:.1f}, {p2_upper:.1f}] hours")
    w_fixed = pred_upper - pred_lower
    w_two = p2_upper - p2_lower
    print(f"  Fixed-parameter interval was [{pred_lower:.1f}, {pred_upper:.1f}] "
          f"(width {w_fixed:.1f} h); two-stage width is {w_two:.1f} h "
          f"({w_two - w_fixed:+.1f} h).")
    se_mc = np.sqrt(prob_fail * (1 - prob_fail) / len(simulated_lifespans))
    print(f"  Monte Carlo standard error of P(failure before {warranty_hours} h) "
          f"at 100,000 draws: about {se_mc:.2%}")
    ex_lo, ex_hi = stats.weibull_min.ppf([0.025, 0.975], shape, loc=0, scale=scale)
    print(f"  Exact 95% interval from the fitted quantile function: "
          f"[{ex_lo:.1f}, {ex_hi:.1f}] hours")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(two_stage_lifespans, bins=100, density=True, alpha=0.6,
            label='Simulated (two-stage)')
    ax.axvline(warranty_hours, color='red', linestyle='--',
               label=f'Warranty = {warranty_hours}h')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Two-Stage Monte Carlo: parameter uncertainty propagated')
    ax.legend()
    save_fig(fig, outdir, "phase8b_monte_carlo_two_stage.png")

# ==================================================================
# PHASE 9 — Reliability Metrics (Based on Weibull)
# ==================================================================
    print("\n--- PHASE 9: Reliability Metrics ---")
    b10_life = stats.weibull_min.ppf(0.10, shape, loc=0, scale=scale)
    print(f"B10 Life: {b10_life:.2f} hours")

    print("\nWeibull-based failure probabilities:")
    for w in [100, 250, 500, 750, 1000, 1200]:
        prob = stats.weibull_min.cdf(w, shape, loc=0, scale=scale)
        print(f"  P(failure before {w:>4}h) = {prob:.3%}")

    print(f"\nWeibull shape = {shape:.4f}")
    if shape > 1:
        print("Shape > 1 -> increasing hazard (wear-out). Failure rate grows over time.")
    else:
        print("Shape <= 1 -> decreasing or constant hazard.")


# ==================================================================
# PHASE 10 — Sensitivity and model-dependence checks
# ==================================================================
    print("\n--- PHASE 10: Sensitivity and Model-Dependence Checks ---")

# 10a. Median/mean ratio: Exponential expectation vs the observed value
    ratio_obs = np.median(lifespans) / np.mean(lifespans)
    rng_sim = np.random.default_rng(123)
    ratios = np.array([np.median(x) / np.mean(x)
                       for x in rng_sim.exponential(1.0, size=(100_000, len(lifespans)))])
    print("\n10a. Median / mean")
    print(f"  Exponential: median = ln(2) x mean, ratio = {np.log(2):.3f}")
    print(f"  Observed ratio = {ratio_obs:.3f}; share of simulated Exponential "
          f"samples (n={len(lifespans)}) with a ratio at least this large: "
          f"{np.mean(ratios >= ratio_obs):.4%}")
    print(f"  Sample skewness = {stats.skew(lifespans):.3f}; fitted Weibull skewness = "
          f"{stats.weibull_min.stats(shape, scale=scale, moments='s'):.3f}")
    print(f"  Fitted Weibull mean = {stats.weibull_min.mean(shape, scale=scale):.1f} h, "
          f"median = {stats.weibull_min.median(shape, scale=scale):.1f} h")
    print(f"  Standard error of the mean = "
          f"{np.std(lifespans, ddof=1) / np.sqrt(len(lifespans)):.1f} h; "
          f"mean - median = {np.mean(lifespans) - np.median(lifespans):.1f} h")

# 10b. Hazard of the fitted Weibull
    print("\n10b. Fitted Weibull hazard, h(t) = (k/scale) (t/scale)^(k-1), per hour")
    for t in (500, 1000, 1500):
        hz = (shape / scale) * (t / scale) ** (shape - 1)
        print(f"  h({t}) = {hz:.2e}")
    print(f"  Exponential (constant): {lambda_mle:.2e}")

# 10c. Uncertainty of derived quantities across the Phase 7 bootstrap fits
    bs_k = np.asarray(bootstrap_shapes)
    bs_s = np.asarray(bootstrap_scales)
    print("\n10c. Bootstrap uncertainty of derived quantities (10,000 refits)")
    print(f"  Shape: min {bs_k.min():.2f}, median {np.median(bs_k):.2f}, "
          f"mean {bs_k.mean():.2f}, max {bs_k.max():.2f}; "
          f"resamples with k <= 1: {int(np.sum(bs_k <= 1))}")
    for label, vals in (
        ("P(failure before  500 h)", stats.weibull_min.cdf(500, bs_k, scale=bs_s)),
        ("P(failure before 1000 h)", stats.weibull_min.cdf(1000, bs_k, scale=bs_s)),
        ("B10 life (hours)", stats.weibull_min.ppf(0.10, bs_k, scale=bs_s)),
    ):
        lo, hi = np.percentile(vals, [2.5, 97.5])
        if "P(" in label:
            print(f"  {label}: 95% interval [{lo:.2%}, {hi:.2%}]")
        else:
            print(f"  {label}: 95% interval [{lo:.1f}, {hi:.1f}]")

# 10d. Model dependence of tail quantities
    print("\n10d. Model dependence (each model fitted by maximum likelihood)")
    models = [
        ("Weibull (2p)", stats.weibull_min, (shape, 0, scale)),
        ("Lognormal",    stats.lognorm,     (ln_shape, 0, ln_scale)),
        ("Gamma",        stats.gamma,       (g_shape, 0, g_scale)),
        ("Weibull (3p)", stats.weibull_min, (shape3, loc3, scale3)),
    ]
    print(f"  {'Model':<14}{'P<500h':>10}{'P<750h':>10}{'P<1000h':>10}{'P<1200h':>10}"
          f"{'B10 (h)':>10}{'P(>=max)':>11}")
    for name, dist, args in models:
        print(f"  {name:<14}{dist.cdf(500, *args):>10.4%}{dist.cdf(750, *args):>10.3%}"
              f"{dist.cdf(1000, *args):>10.2%}{dist.cdf(1200, *args):>10.2%}"
              f"{dist.ppf(0.10, *args):>10.1f}{dist.sf(lifespans.max(), *args):>11.2e}")
    print(f"  Empirical: P(<750) = {np.mean(lifespans < 750):.2%}, "
          f"P(<1000) = {np.mean(lifespans < 1000):.2%}, "
          f"P(<1200) = {np.mean(lifespans < 1200):.2%}, "
          f"10th percentile = {np.percentile(lifespans, 10):.1f} h")
    p_max = stats.weibull_min.sf(lifespans.max(), shape, loc=0, scale=scale)
    print(f"  Fitted Weibull (2p): expected number of bulbs >= {lifespans.max()} h "
          f"among {len(lifespans)} = {len(lifespans) * p_max:.4f}")

# 10e. Effect of the longest bulb on the Weibull fit
    k_wo, _, s_wo = stats.weibull_min.fit(lifespans[lifespans < lifespans.max()], floc=0)
    print(f"\n10e. Weibull (2p) refit without the {lifespans.max()} h bulb: "
          f"k = {k_wo:.3f}, scale = {s_wo:.1f}")

# 10f. Interval-censored Weibull fit (failures checked every 12 h,
#      so each recorded time h is treated as the interval (h - 12, h])
    from scipy import optimize
    fail = df[df['f'] > 0]
    hi_t = fail['h'].values.astype(float)
    cnt = fail['f'].values

    def nll_interval(params):
        k_, s_ = np.exp(params)
        pr = (stats.weibull_min.cdf(hi_t, k_, scale=s_)
              - stats.weibull_min.cdf(hi_t - 12, k_, scale=s_))
        return -np.sum(cnt * np.log(np.clip(pr, 1e-300, None)))

    res = optimize.minimize(nll_interval, [np.log(4.0), np.log(1500.0)],
                            method='Nelder-Mead',
                            options=dict(xatol=1e-8, fatol=1e-10, maxiter=5000))
    k_ic, s_ic = np.exp(res.x)
    b10_ic = stats.weibull_min.ppf(0.10, k_ic, scale=s_ic)
    print(f"\n10f. Interval-censored Weibull (12 h intervals): k = {k_ic:.3f}, "
          f"scale = {s_ic:.1f}, B10 = {b10_ic:.1f} h")
    print(f"     (exact-time fit: k = {shape:.3f}, scale = {scale:.1f}, B10 = {b10_life:.1f} h)")

# 10g. Profile over the Weibull location parameter
    print("\n10g. Weibull fit with the location fixed at each value")
    print(f"  {'loc':>6}{'k':>8}{'scale':>9}{'logLik':>10}")
    for loc_fixed in (0, 300, 500, 700, 742, 820):
        k_l, _, s_l = stats.weibull_min.fit(lifespans, floc=loc_fixed)
        ll_l = np.sum(stats.weibull_min.logpdf(lifespans, k_l, loc_fixed, s_l))
        print(f"  {loc_fixed:>6}{k_l:>8.3f}{s_l:>9.1f}{ll_l:>10.2f}")

# 10h. Probability-plot reference line (scipy fits a least-squares line)
    (_, _), (qq_slope, qq_intercept, _) = stats.probplot(lifespans, dist="expon")
    print(f"\n10h. Exponential Q-Q reference line: slope {qq_slope:.1f}, "
          f"intercept {qq_intercept:.1f} (fitted Exponential: slope {1/lambda_mle:.1f}, intercept 0)")

    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulb Lifespan Dataset Analysis")
    parser.add_argument("--data", default=None, help="Path to local lamps.csv (optional)")
    parser.add_argument("--outdir", default="output/figures", help="Directory to save figures")
    args = parser.parse_args()
    main(data_path=args.data, outdir=args.outdir)