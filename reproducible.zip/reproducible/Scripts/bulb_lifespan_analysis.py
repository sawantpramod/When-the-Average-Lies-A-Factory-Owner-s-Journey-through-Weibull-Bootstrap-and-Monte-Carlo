"""
Bulb Lifespan Dataset Analysis
------------------------------
Phase-wise reproducible analysis of bulb lifespans.
Saves figures to output/figures and prints key statistics.

Run from CMD:
    python Scripts\bulb_lifespan_analysis.py --data lamps.csv --outdir .
"""

import argparse
import io
import os
import urllib.error
import urllib.request

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats


# ----------------------------------------------------------------------
# Data sources — tried in order until one succeeds
# ----------------------------------------------------------------------
DATA_URLS = [
    "https://gist.githubusercontent.com/epogrebnyak/7933e16c0ad215742c4c104be4fbdeb1/"
    "raw/c932bc5b6aa6317770c4cbf43eb591511fec08f9/lamps.csv",
    "https://gist.githubusercontent.com/epogrebnyak/7933e16c0ad215742c4c104be4fbdeb1/"
    "raw/lamps.csv",
    "https://raw.githubusercontent.com/epogrebnyak/data/main/lamps.csv",
]


def load_dataframe(data_path=None):
    """Load the lamps dataframe from a local file or any of the fallback URLs."""
    if data_path:
        print(f"Loading data from local file: {data_path}")
        return pd.read_csv(data_path, index_col=0)

    last_error = None
    for url in DATA_URLS:
        try:
            print(f"Trying URL: {url}")
            with urllib.request.urlopen(url, timeout=15) as resp:
                raw = resp.read().decode("utf-8")
            df = pd.read_csv(io.StringIO(raw), index_col=0)
            print(f"  -> OK  ({len(df)} rows)")
            return df
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
            print(f"  -> failed: {exc}")
            last_error = exc
        except Exception as exc:
            print(f"  -> failed: {exc}")
            last_error = exc

    raise RuntimeError(
        "Could not download the lamps dataset from any known URL.\n"
        "Please save the CSV locally (e.g. lamps.csv) and run:\n"
        "    python Scripts\\bulb_lifespan_analysis.py --data lamps.csv"
    ) from last_error


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def save_fig(fig, outdir, name):
    path = os.path.join(outdir, name)
    fig.savefig(path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"  [saved] {path}")


# ----------------------------------------------------------------------
# Tier 1 fix: parametric-bootstrap KS for a fitted Weibull
# ----------------------------------------------------------------------
def parametric_bootstrap_ks(shape, scale, n, ks_obs, n_boot=2000, seed=42):
    """
    Correct the KS p-value for the fact that (shape, scale) were estimated
    from the same sample we're testing.  Under H0, generate a fresh sample
    of size n from Weibull(shape, scale), refit (k, lam) on that sample,
    and record the KS statistic.  The corrected p-value is the fraction of
    bootstrap KS statistics that meet or exceed the observed one.
    """
    rng = np.random.default_rng(seed)
    boot_ks = np.empty(n_boot)
    for i in range(n_boot):
        sample = stats.weibull_min.rvs(shape, scale=scale, size=n, random_state=rng)
        k_b, _, s_b = stats.weibull_min.fit(sample, floc=0)
        ks_b, _ = stats.kstest(sample, 'weibull_min', args=(k_b, 0, s_b))
        boot_ks[i] = ks_b
    return float(np.mean(boot_ks >= ks_obs))


# ----------------------------------------------------------------------
# Main analysis
# ----------------------------------------------------------------------
def main(data_path=None, outdir="output/figures"):
    ensure_dir(outdir)
    print("=" * 70)
    print("BULB LIFESPAN DATASET ANALYSIS")
    print("=" * 70)

    # ==================================================================
    # PHASE 1 — Data Loading & Descriptive Statistics
    # ==================================================================
    print("\n--- PHASE 1: Data Loading & Descriptive Statistics ---")
    df = load_dataframe(data_path)

    # ------------------------------------------------------------------
    # About-the-data block (Tier 2).  We describe the raw structure so
    # the article's Section 2 can quote this verbatim instead of
    # describing the dataset from memory.
    # ------------------------------------------------------------------
    print("\n  About the raw data (lamps.csv):")
    print(f"    Columns: {list(df.columns)}  (i=index, h=hours, f=frequency, K=count remaining)")
    print(f"    Rows: {len(df)} distinct hour-values")
    print(f"    Total bulbs (sum of 'f'): {int(df['f'].sum())}")
    print(f"    Distinct hour-values: {df['h'].nunique()} "
          f"(min {df['h'].min()} h, max {df['h'].max()} h)")
    print(f"    Repeated hour-values (ties): "
          f"{int((df['f'] > 1).sum())} rows have f > 1")
    print(f"    Grouping note: with only {df['h'].nunique()} distinct values "
          f"across {int(df['f'].sum())} bulbs,")
    print(f"    the lifespans appear to have been recorded in a life-table / "
          f"binned form rather than measured to the second.")

    lifespans = np.repeat(df['h'].values, df['f'].values)
    print(f"\nTotal bulbs: {len(lifespans)}")
    print(f"Mean lifespan: {np.mean(lifespans):.2f} hours")
    print(f"Std deviation: {np.std(lifespans):.2f} hours")
    print(f"Median lifespan: {np.median(lifespans):.2f} hours")
    print(f"Min / Max: {lifespans.min()} / {lifespans.max()} hours")

    # ==================================================================
    # PHASE 2 — Visualizing the Data First
    # ==================================================================
    print("\n--- PHASE 2: Visualizing the Data ---")
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(lifespans, bins=15, edgecolor='black', alpha=0.7)
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Frequency')
    ax.set_title('Distribution of Bulb Lifespans (Raw Data)')
    save_fig(fig, outdir, "phase2_histogram_raw.png")

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.boxplot(lifespans, vert=False)
    ax.set_xlabel('Lifespan (hours)')
    ax.set_title('Box Plot of Bulb Lifespans')
    save_fig(fig, outdir, "phase2_boxplot.png")

    # ==================================================================
    # PHASE 3 — Outlier Detection (IQR Method)
    # ==================================================================
    print("\n--- PHASE 3: Outlier Detection (IQR) ---")
    Q1 = np.percentile(lifespans, 25)
    Q3 = np.percentile(lifespans, 75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = lifespans[(lifespans < lower_bound) | (lifespans > upper_bound)]
    print(f"Q1 = {Q1:.2f}, Q3 = {Q3:.2f}, IQR = {IQR:.2f}")
    print(f"Normal range: [{lower_bound:.2f}, {upper_bound:.2f}] hours")
    print(f"Outliers detected: {outliers}")

    # ==================================================================
    # PHASE 4 — Fit the Exponential (Baseline Model)
    # ==================================================================
    print("\n--- PHASE 4: Exponential Baseline Model ---")
    lambda_mle = 1 / np.mean(lifespans)
    print(f"MLE estimate of failure rate (λ): {lambda_mle:.6f} per hour")
    print(f"Mean time to failure (MTTF): {1/lambda_mle:.2f} hours")

    x = np.linspace(0, max(lifespans), 1000)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(lifespans, bins=15, density=True, alpha=0.6, label='Observed')
    ax.plot(x, stats.expon.pdf(x, scale=1/lambda_mle), 'r-', label='Fitted Exponential')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Bulb Lifespan Distribution vs Fitted Exponential')
    ax.legend()
    save_fig(fig, outdir, "phase4_hist_exponential.png")

    sorted_data = np.sort(lifespans)
    ecdf = np.arange(1, len(sorted_data) + 1) / len(sorted_data)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.step(sorted_data, ecdf, where='post', label='Empirical CDF')
    ax.plot(x, stats.expon.cdf(x, scale=1/lambda_mle), 'r-', label='Fitted Exponential CDF')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Cumulative Probability')
    ax.set_title('Empirical vs Fitted CDF')
    ax.legend()
    save_fig(fig, outdir, "phase4_ecdf.png")

    fig, ax = plt.subplots(figsize=(8, 8))
    stats.probplot(lifespans, dist="expon", plot=ax)
    ax.set_title('Q-Q Plot: Bulb Lifespans vs Exponential')
    save_fig(fig, outdir, "phase4_qq_exponential.png")

    # ==================================================================
    # PHASE 5 — Goodness-of-Fit Test (Reject Exponential)
    # ==================================================================
    print("\n--- PHASE 5: Goodness-of-Fit Test vs Exponential ---")
    ks_stat, ks_p = stats.kstest(lifespans, 'expon', args=(0, 1/lambda_mle))
    print(f"KS statistic = {ks_stat:.4f}")
    print(f"KS p-value   = {ks_p:.4f}")

    # ==================================================================
    # PHASE 6 — Fit the Weibull (Better Model) & Compare
    # ==================================================================
    print("\n--- PHASE 6: Weibull Model & Comparison ---")
    shape, loc, scale = stats.weibull_min.fit(lifespans, floc=0)
    print(f"Weibull shape (k)  = {shape:.4f}")
    print(f"Weibull scale (λ)  = {scale:.4f}")
    print(f"Weibull location   = {loc:.4f}")

    ll_exp = np.sum(stats.expon.logpdf(lifespans, scale=1/lambda_mle))
    ll_weibull = np.sum(stats.weibull_min.logpdf(lifespans, shape, loc=0, scale=scale))

    aic_exp = 2*1 - 2*ll_exp
    aic_weibull = 2*2 - 2*ll_weibull
    bic_exp = 1*np.log(len(lifespans)) - 2*ll_exp
    bic_weibull = 2*np.log(len(lifespans)) - 2*ll_weibull

    print(f"\nLog-likelihood Exponential: {ll_exp:.2f}")
    print(f"Log-likelihood Weibull:     {ll_weibull:.2f}")
    print(f"AIC Exponential: {aic_exp:.2f}")
    print(f"AIC Weibull:     {aic_weibull:.2f}")
    print(f"BIC Exponential: {bic_exp:.2f}")
    print(f"BIC Weibull:     {bic_weibull:.2f}")

    ks_w_stat, ks_w_p = stats.kstest(lifespans, 'weibull_min', args=(shape, 0, scale))
    print(f"\nWeibull KS statistic = {ks_w_stat:.4f}")
    print(f"Weibull KS p-value   = {ks_w_p:.4f}")

    # ------------------------------------------------------------------
    # Tier 1 fix — Likelihood-ratio test: Exponential is nested in
    # Weibull (k = 1).  df = 1 (one extra parameter).
    # ------------------------------------------------------------------
    lrt_stat = 2.0 * (ll_weibull - ll_exp)
    p_lrt = stats.chi2.sf(lrt_stat, df=1)
    print(f"\nLikelihood-ratio test (Weibull vs Exponential, df=1):")
    print(f"  LRT statistic = {lrt_stat:.2f}")
    print(f"  p-value       = {p_lrt:.3e}")
    if p_lrt < 0.0001:
        print("  -> Exponential formally rejected in favour of Weibull (p < 0.0001).")

    # ------------------------------------------------------------------
    # Tier 1 fix — the KS p-value above is optimistically biased because
    # (k, λ) were estimated from the same sample.  Correct it with a
    # parametric bootstrap.
    # ------------------------------------------------------------------
    print("\nParametric-bootstrap KS correction (2000 resamples)...")
    ks_w_p_corrected = parametric_bootstrap_ks(
        shape, scale, n=len(lifespans), ks_obs=ks_w_stat,
        n_boot=2000, seed=42
    )
    print(f"  Corrected Weibull KS p-value = {ks_w_p_corrected:.4f}")
    if ks_w_p_corrected > 0.05:
        print("  -> Weibull still not rejected after correction.")
    else:
        print("  -> After correction, Weibull is also rejected; "
              "consider Lognormal / Gamma (Phase 6b).")

    # ==================================================================
    # PHASE 6b — Alternative distributions (Tier 1 response)
    # Compare Weibull against Lognormal and Gamma; also fit a free-
    # location 3-parameter Weibull (Tier 2).
    # ==================================================================
    print("\n--- PHASE 6b: Alternative Distribution Comparison ---")

    # Each entry: (label, loglik, k_params, ks_p, notes)
    comparison = []
    comparison.append(("Exponential",  ll_exp,     1, ks_p,       "baseline"))
    comparison.append(("Weibull (2p)", ll_weibull, 2, ks_w_p,     "floc=0"))
    # Weibull KS p is the *uncorrected* one; note it separately below.

    # Lognormal (floc=0 for consistency with a lifetime dist.)
    ln_shape, ln_loc, ln_scale = stats.lognorm.fit(lifespans, floc=0)
    ll_ln = np.sum(stats.lognorm.logpdf(lifespans, ln_shape, loc=0, scale=ln_scale))
    ks_ln_stat, ks_ln_p = stats.kstest(
        lifespans, 'lognorm', args=(ln_shape, 0, ln_scale)
    )
    comparison.append(("Lognormal",   ll_ln, 2, ks_ln_p, f"σ={ln_shape:.3f}, "
                                                         f"scale={ln_scale:.1f}"))

    # Gamma (floc=0)
    g_shape, g_loc, g_scale = stats.gamma.fit(lifespans, floc=0)
    ll_g = np.sum(stats.gamma.logpdf(lifespans, g_shape, loc=0, scale=g_scale))
    ks_g_stat, ks_g_p = stats.kstest(
        lifespans, 'gamma', args=(g_shape, 0, g_scale)
    )
    comparison.append(("Gamma",       ll_g, 2, ks_g_p, f"α={g_shape:.3f}, "
                                                      f"scale={g_scale:.1f}"))

    # 3-parameter Weibull (free location) — Tier 2
    shape3, loc3, scale3 = stats.weibull_min.fit(lifespans)
    ll_w3 = np.sum(stats.weibull_min.logpdf(lifespans, shape3, loc3, scale3))
    ks_w3_stat, ks_w3_p = stats.kstest(
        lifespans, 'weibull_min', args=(shape3, loc3, scale3)
    )
    comparison.append(("Weibull (3p)", ll_w3, 3, ks_w3_p,
                       f"k={shape3:.3f}, loc={loc3:.1f}, scale={scale3:.1f}"))

    n = len(lifespans)
    print(f"\n{'Model':<15}{'k':>3}{'LogLik':>12}{'AIC':>10}{'BIC':>10}"
          f"{'KS p':>10}   Notes")
    print("-" * 90)
    for name, ll, kpar, ksp, note in comparison:
        aic = 2 * kpar - 2 * ll
        bic = kpar * np.log(n) - 2 * ll
        print(f"{name:<15}{kpar:>3}{ll:>12.2f}{aic:>10.2f}{bic:>10.2f}"
              f"{ksp:>10.4f}   {note}")

    # Interpretation helper
    print("\nInterpretation of Phase 6b:")
    print("  * Lower AIC/BIC is better; higher KS p is better.")
    print("  * If Lognormal / Gamma are within ~2 AIC of Weibull, the three are")
    print("    statistically indistinguishable at n=50 — say so explicitly rather")
    print("    than claiming Weibull is uniquely correct.")
    print("  * Weibull is retained on reliability-engineering convention and the")
    print("    physical interpretability of its shape parameter (k > 1 -> wear-out).")

    # Free-location check (Tier 2)
    print(f"\nFree-location Weibull check:")
    print(f"  2p:  k={shape:.4f}, λ={scale:.4f}, AIC={aic_weibull:.2f}")
    print(f"  3p:  k={shape3:.4f}, loc={loc3:.4f}, λ={scale3:.4f}, AIC={2*3-2*ll_w3:.2f}")
    if abs(loc3) < 1.0 and (2*3 - 2*ll_w3) >= aic_weibull - 2:
        print("  -> loc ≈ 0 and no meaningful AIC gain; the 2-parameter form is preferred.")
    else:
        print("  -> A free-location Weibull may offer a real improvement; "
              "investigate before settling on the 2p model.")

    # ==================================================================
    # PHASE 7 — Bootstrap Confidence Interval (Weibull parameters)
    # ==================================================================
    print("\n--- PHASE 7: Bootstrap Confidence Intervals ---")
    np.random.seed(42)
    n_bootstrap = 10_000
    bootstrap_shapes = []
    bootstrap_scales = []
    for _ in range(n_bootstrap):
        sample = np.random.choice(lifespans, size=len(lifespans), replace=True)
        k_b, _, s_b = stats.weibull_min.fit(sample, floc=0)
        bootstrap_shapes.append(k_b)
        bootstrap_scales.append(s_b)

    shape_lower, shape_upper = np.percentile(bootstrap_shapes, [2.5, 97.5])
    scale_lower, scale_upper = np.percentile(bootstrap_scales, [2.5, 97.5])
    print(f"95% CI for shape (k): [{shape_lower:.3f}, {shape_upper:.3f}]")
    print(f"95% CI for scale (λ): [{scale_lower:.1f}, {scale_upper:.1f}]")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(bootstrap_shapes, bins=50, density=True, alpha=0.7, edgecolor='black')
    ax.axvline(shape, color='red', linestyle='--', label=f'Point estimate k = {shape:.3f}')
    ax.axvline(shape_lower, color='green', linestyle=':', label=f'2.5% = {shape_lower:.3f}')
    ax.axvline(shape_upper, color='green', linestyle=':', label=f'97.5% = {shape_upper:.3f}')
    ax.set_xlabel('Weibull shape (k)')
    ax.set_ylabel('Frequency')
    ax.set_title('Bootstrap Distribution of Weibull Shape Parameter')
    ax.legend()
    save_fig(fig, outdir, "phase7_bootstrap_shape.png")

    # ==================================================================
    # PHASE 8 — Monte Carlo Simulation (Using Weibull)
    # ==================================================================
    print("\n--- PHASE 8: Monte Carlo Simulation ---")
    # NOTE (Tier 3): 500 h is illustrative — it is NOT a real warranty
    # length from the dataset.  It sits below the minimum observed
    # lifespan (840 h), so this number is a model-based extrapolation.
    warranty_hours = 500
    simulated_lifespans = stats.weibull_min.rvs(shape, loc=0, scale=scale, size=100_000)
    prob_fail = np.mean(simulated_lifespans < warranty_hours)
    print(f"P(failure before {warranty_hours} h) = {prob_fail:.2%}")
    print(f"  [Note: {warranty_hours} h is illustrative and lies below the "
          f"minimum observed lifespan ({lifespans.min()} h).]")

    pred_lower, pred_upper = np.percentile(simulated_lifespans, [2.5, 97.5])
    print(f"95% prediction interval (parameter-fixed): "
          f"[{pred_lower:.1f}, {pred_upper:.1f}] hours")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(simulated_lifespans, bins=100, density=True, alpha=0.6, label='Simulated (Weibull)')
    ax.axvline(warranty_hours, color='red', linestyle='--', label=f'Warranty = {warranty_hours}h')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Monte Carlo Simulation of 100,000 Bulbs (Weibull model)')
    ax.legend()
    save_fig(fig, outdir, "phase8_monte_carlo.png")

    # ==================================================================
    # PHASE 8b — Two-stage Monte Carlo (Tier 3: propagate parameter
    # uncertainty).  Draw (k, λ) from the Phase 7 bootstrap, then draw
    # one lifespan from that specific Weibull.
    # ==================================================================
    print("\n--- PHASE 8b: Two-Stage Monte Carlo (with parameter uncertainty) ---")
    rng = np.random.default_rng(seed=7)
    idx = rng.integers(0, len(bootstrap_shapes), size=100_000)
    k_arr = np.asarray(bootstrap_shapes)[idx]
    lam_arr = np.asarray(bootstrap_scales)[idx]
    # Inverse-CDF sampling from Weibull: X = λ (-ln U)^(1/k)
    U = rng.uniform(size=100_000)
    two_stage_lifespans = lam_arr * (-np.log(U)) ** (1.0 / k_arr)

    prob_fail_2s = np.mean(two_stage_lifespans < warranty_hours)
    p2_lower, p2_upper = np.percentile(two_stage_lifespans, [2.5, 97.5])
    print(f"P(failure before {warranty_hours} h) = {prob_fail_2s:.2%}")
    print(f"95% prediction interval (parameter-propagated): "
          f"[{p2_lower:.1f}, {p2_upper:.1f}] hours")
    print(f"  (Fixed-parameter interval was [{pred_lower:.1f}, {pred_upper:.1f}]; "
          f"the two-stage interval is wider, as expected.)")

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(two_stage_lifespans, bins=100, density=True, alpha=0.6,
            label='Simulated (two-stage)')
    ax.axvline(warranty_hours, color='red', linestyle='--',
               label=f'Warranty = {warranty_hours}h')
    ax.set_xlabel('Lifespan (hours)')
    ax.set_ylabel('Density')
    ax.set_title('Two-Stage Monte Carlo: parameter uncertainty propagated')
    ax.legend()
    save_fig(fig, outdir, "phase8b_monte_carlo_two_stage.png")

    # ==================================================================
    # PHASE 9 — Reliability Metrics (Based on Weibull)
    # ==================================================================
    print("\n--- PHASE 9: Reliability Metrics ---")
    b10_life = stats.weibull_min.ppf(0.10, shape, loc=0, scale=scale)
    print(f"B10 Life: {b10_life:.2f} hours")

    print("\nWeibull-based failure probabilities:")
    for w in [100, 250, 500, 750, 1000, 1200]:
        prob = stats.weibull_min.cdf(w, shape, loc=0, scale=scale)
        print(f"  P(failure before {w:>4}h) = {prob:.3%}")

    print(f"\nWeibull shape = {shape:.4f}")
    if shape > 1:
        print("Shape > 1 -> increasing hazard (wear-out). Failure rate grows over time.")
    else:
        print("Shape <= 1 -> decreasing or constant hazard.")

    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulb Lifespan Dataset Analysis")
    parser.add_argument("--data", default=None, help="Path to local lamps.csv (optional)")
    parser.add_argument("--outdir", default="output/figures", help="Directory to save figures")
    args = parser.parse_args()
    main(data_path=args.data, outdir=args.outdir)