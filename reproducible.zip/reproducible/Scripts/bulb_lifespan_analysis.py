"""
Bulb Lifespan Analysis
--------------------------------
Reproducible analysis of the 50-lamp dataset (Menon & Agrawal, 2007).
Every number in the article can be regenerated exactly.

Run:  python bulb_lifespan_analysis.py [--data lamps.csv] [--outdir output/figures]
"""

import argparse
import io
import os
import urllib.request

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize

SEED = 42
WARRANTY_H = 900        # candidate warranty, inside the observed range
CHECK_H = 1000          # second in-range check
BATCH = 10000          # bulbs per simulated production batch

DATA_URLS = [
    "https://gist.githubusercontent.com/epogrebnyak/7933e16c0ad215742c4c104be4fbdeb1/"
    "raw/c932bc5b6aa6317770c4cbf43eb591511fec08f9/lamps.csv",
    "https://github.com/AllenDowney/SurvivalAnalysisPython/raw/master/lamps.csv",
]


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def load_dataframe(data_path=None):
    if data_path:
        print(f"Loading data from local file: {data_path}")
        return pd.read_csv(data_path, index_col=0)
    last = None
    for url in DATA_URLS:
        try:
            print(f"Trying URL: {url}")
            with urllib.request.urlopen(url, timeout=15) as resp:
                raw = resp.read().decode("utf-8")
            df = pd.read_csv(io.StringIO(raw), index_col=0)
            print(f"  -> OK ({len(df)} rows)")
            return df
        except Exception as exc:                      
            print(f"  -> failed: {exc}")
            last = exc
    raise RuntimeError("Could not download lamps.csv. Save it locally and run "
                       "with --data lamps.csv") from last


def save_fig(fig, outdir, name):
    path = os.path.join(outdir, name)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  [saved] {path}")


def weibull_mle(x):
    """Exact 2-parameter Weibull MLE (location = 0).

    Solves  sum(x^k ln x)/sum(x^k) - 1/k - mean(ln x) = 0  for k, then
    scale = (mean(x^k))^(1/k).  Fast and stable enough for 10,000 refits.
    """
    x = np.asarray(x, float)
    c = x.max()
    xs = x / c
    lx = np.log(xs)

    def g(k):
        xk = xs ** k
        return np.sum(xk * lx) / np.sum(xk) - 1.0 / k - lx.mean()

    k = optimize.brentq(g, 0.01, 200.0)
    scale = c * np.mean(xs ** k) ** (1.0 / k)
    return k, scale


def wb_loglik(x, k, s, loc=0.0):
    return np.sum(stats.weibull_min.logpdf(x, k, loc=loc, scale=s))


def profile_ll_k(x, k):
    """Log-likelihood at shape k with the scale set to its conditional MLE."""
    s = np.mean(x ** k) ** (1.0 / k)
    return wb_loglik(x, k, s)


def bca_interval(boot, theta_hat, jack, alpha=0.05):
    """Bias-corrected and accelerated bootstrap interval."""
    z0 = stats.norm.ppf(np.mean(boot < theta_hat))
    d = jack.mean() - jack
    a = np.sum(d ** 3) / (6.0 * np.sum(d ** 2) ** 1.5)
    zs = stats.norm.ppf([alpha / 2, 1 - alpha / 2])
    adj = stats.norm.cdf(z0 + (z0 + zs) / (1 - a * (z0 + zs)))
    return np.percentile(boot, 100 * adj)


def parametric_bootstrap_ks(k, s, n, ks_obs, rng, n_boot=2000):
    """p-value of the KS statistic when (k, scale) are estimated from the data."""
    out = np.empty(n_boot)
    for i in range(n_boot):
        smp = stats.weibull_min.rvs(k, scale=s, size=n, random_state=rng)
        kb, sb = weibull_mle(smp)
        out[i] = stats.kstest(smp, "weibull_min", args=(kb, 0, sb))[0]
    return float(np.mean(out >= ks_obs))


def weibull_hazard(t, k, s):
    return (k / s) * (t / s) ** (k - 1)


# ----------------------------------------------------------------------
def main(data_path=None, outdir="output/figures"):
    os.makedirs(outdir, exist_ok=True)
    rng = np.random.default_rng(SEED)
    line = "=" * 70
    print(line, "\nBULB LIFESPAN ANALYSIS (revised)\n" + line)

    # ==================================================================
    # 1. Data
    # ==================================================================
    print("\n--- 1. Data ---")
    df = load_dataframe(data_path)
    fails = df[df["f"] > 0]                      # drop the h = 0 origin row
    x = np.repeat(fails["h"].values, fails["f"].values).astype(float)
    n = len(x)
    print(f"  Bulbs: {n}   distinct failure times: {len(fails)}   "
          f"rows with ties (f > 1): {int((fails['f'] > 1).sum())}")
    print(f"  Min / max: {x.min():.0f} / {x.max():.0f} h")
    print(f"  All times multiples of 12 h: {bool((fails['h'] % 12 == 0).all())}")
    print(f"  Survivors after last failure: {int(df['K'].iloc[-1])} (0 = no censoring)")
    print(f"  Mean {x.mean():.2f}   median {np.median(x):.2f}   "
          f"SD (n-1) {x.std(ddof=1):.2f}   CV {x.std(ddof=1) / x.mean():.3f}")
    q1, q3 = np.percentile(x, [25, 75])
    iqr = q3 - q1
    print(f"  IQR fences [{q1 - 1.5 * iqr:.1f}, {q3 + 1.5 * iqr:.1f}]  "
          f"outliers: {x[(x < q1 - 1.5 * iqr) | (x > q3 + 1.5 * iqr)]}   "
          f"(extreme fence upper {q3 + 3 * iqr:.1f})")

    # ==================================================================
    # 2. Exponential baseline
    # ==================================================================
    print("\n--- 2. Exponential baseline ---")
    lam = 1.0 / x.mean()
    ll_exp = np.sum(stats.expon.logpdf(x, scale=1 / lam))
    print(f"  lambda_hat = {lam:.6f} per hour  (MTTF {1 / lam:.2f} h)")
    p840_exp = stats.expon.cdf(840, scale=1 / lam)
    print(f"  Exponential P(fail by 840 h) = {p840_exp:.3f};  observed share "
          f"with lifetime <= 840 h: {np.mean(x <= 840):.3f} ({int(np.sum(x <= 840))} of {n})")
    ks_e, ks_e_p = stats.kstest(x, "expon", args=(0, 1 / lam))
    print(f"  KS D = {ks_e:.4f}, p = {ks_e_p:.2e}  (lambda estimated -> p is conservative; ties -> approximate)")
    print(f"  Exponential B10 = {stats.expon.ppf(0.10, scale=1 / lam):.1f} h")

    tt = np.linspace(0, x.max() * 1.02, 1000)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.hist(x, bins=15, density=True, alpha=0.6, edgecolor="black", label="Observed")
    ax.plot(tt, stats.expon.pdf(tt, scale=1 / lam), "r-", label="Fitted Exponential")
    ax.set_xlabel("Lifespan (hours)"); ax.set_ylabel("Density")
    ax.set_title("Bulb lifespans vs fitted Exponential"); ax.legend()
    save_fig(fig, outdir, "fig1_hist_exponential.png")

    xs_sorted = np.sort(x)
    ecdf = np.arange(1, n + 1) / n
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.step(xs_sorted, ecdf, where="post", label="Empirical CDF")
    ax.plot(tt, stats.expon.cdf(tt, scale=1 / lam), "r-", label="Fitted Exponential CDF")
    ax.set_xlabel("Lifespan (hours)"); ax.set_ylabel("Cumulative probability")
    ax.set_title("Empirical vs fitted Exponential CDF"); ax.legend()
    save_fig(fig, outdir, "fig2_ecdf_exponential.png")

    # ==================================================================
    # 3. Weibull
    # ==================================================================
    print("\n--- 3. Weibull ---")
    k_hat, s_hat = weibull_mle(x)
    k_sp, _, s_sp = stats.weibull_min.fit(x, floc=0)
    print(f"  shape k = {k_hat:.4f}, scale = {s_hat:.4f}   "
          f"(scipy fit agrees: {k_sp:.4f}, {s_sp:.4f})")
    ll_w = wb_loglik(x, k_hat, s_hat)
    lrt = 2 * (ll_w - ll_exp)
    print(f"  logLik Exp {ll_exp:.2f}, Weibull {ll_w:.2f};  LRT (df=1) = {lrt:.2f}, p = {stats.chi2.sf(lrt, 1):.2e}")
    ks_w, ks_w_p = stats.kstest(x, "weibull_min", args=(k_hat, 0, s_hat))
    ks_w_pc = parametric_bootstrap_ks(k_hat, s_hat, n, ks_w, rng)
    print(f"  Weibull KS D = {ks_w:.4f}; uncorrected p = {ks_w_p:.3f}; "
          f"parametric-bootstrap p = {ks_w_pc:.3f}")
    for t in (500, 1000, 1500):
        print(f"  hazard h({t}) = {weibull_hazard(t, k_hat, s_hat):.2e}   "
              f"(Exponential, constant: {lam:.2e})")
    print(f"  B10 = {s_hat * (-np.log(0.9)) ** (1 / k_hat):.1f} h")

    # ==================================================================
    # 4. Bootstrap, BCa, profile likelihood
    # ==================================================================
    print("\n--- 4. Uncertainty ---")
    n_boot = 10000
    bk = np.empty(n_boot); bs = np.empty(n_boot); be10 = np.empty(n_boot)
    for i in range(n_boot):
        xb = rng.choice(x, size=n, replace=True)
        bk[i], bs[i] = weibull_mle(xb)
        be10[i] = np.percentile(xb, 10)
    jack = np.array([weibull_mle(np.delete(x, i)) for i in range(n)])
    pk = np.percentile(bk, [2.5, 97.5]); ps = np.percentile(bs, [2.5, 97.5])
    bk_ci = bca_interval(bk, k_hat, jack[:, 0]); bs_ci = bca_interval(bs, s_hat, jack[:, 1])
    print(f"  Bootstrap shape: mean {bk.mean():.3f}, median {np.median(bk):.3f} "
          f"(point estimate {k_hat:.3f});  min {bk.min():.2f};  k <= 1 in {int(np.sum(bk <= 1))} resamples")
    print(f"  k  95% percentile [{pk[0]:.3f}, {pk[1]:.3f}]   BCa [{bk_ci[0]:.3f}, {bk_ci[1]:.3f}]")
    print(f"  eta 95% percentile [{ps[0]:.1f}, {ps[1]:.1f}]   BCa [{bs_ci[0]:.1f}, {bs_ci[1]:.1f}]")
    cut = profile_ll_k(x, k_hat) - stats.chi2.ppf(0.95, 1) / 2
    k_lo = optimize.brentq(lambda k: profile_ll_k(x, k) - cut, 1.0, k_hat)
    k_hi = optimize.brentq(lambda k: profile_ll_k(x, k) - cut, k_hat, 30.0)
    print(f"  k  95% profile-likelihood interval [{k_lo:.3f}, {k_hi:.3f}]")

    b10_w_boot = bs * (-np.log(0.9)) ** (1 / bk)
    p_w_boot = {h: stats.weibull_min.cdf(h, bk, scale=bs) for h in (500, WARRANTY_H, CHECK_H)}
    lo, hi = np.percentile(b10_w_boot, [2.5, 97.5])
    print(f"  Weibull B10 95% bootstrap range [{lo:.1f}, {hi:.1f}] h")
    for h in (WARRANTY_H, CHECK_H):
        lo, hi = np.percentile(p_w_boot[h], [2.5, 97.5])
        print(f"  Weibull P(fail < {h} h) 95% bootstrap range [{lo:.2%}, {hi:.2%}]")
    lo, hi = np.percentile(be10, [2.5, 97.5])
    print(f"  Empirical 10th percentile: {np.percentile(x, 10):.1f} h; "
          f"95% bootstrap range [{lo:.1f}, {hi:.1f}]")

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.hist(bk, bins=50, density=True, alpha=0.7, edgecolor="black")
    ax.axvline(k_hat, color="red", ls="--", label=f"Estimate k = {k_hat:.2f}")
    ax.axvline(bk_ci[0], color="green", ls=":", label=f"BCa 95%: [{bk_ci[0]:.2f}, {bk_ci[1]:.2f}]")
    ax.axvline(bk_ci[1], color="green", ls=":")
    ax.axvline(1.0, color="black", ls="-", lw=2, label="k = 1 (constant risk)")
    ax.set_xlim(0, max(8, bk.max())); ax.set_xlabel("Weibull shape (k)"); ax.set_ylabel("Density")
    ax.set_title("Bootstrap distribution of the Weibull shape (10,000 resamples)"); ax.legend()
    save_fig(fig, outdir, "fig4_bootstrap_shape.png")

    # ==================================================================
    # 5. Model Comparison
    # ==================================================================
    print("\n--- 5. Model comparison ---")
    ln_s, _, ln_sc = stats.lognorm.fit(x, floc=0)
    g_a, _, g_sc = stats.gamma.fit(x, floc=0)
    # 3-parameter Weibull: maximise the profile likelihood over location
    def nll_loc(loc):
        k3, s3 = weibull_mle(x - loc)
        return -wb_loglik(x, k3, s3, loc)
    res = optimize.minimize_scalar(nll_loc, bounds=(0, x.min() - 1), method="bounded",
                                   options=dict(xatol=1e-6))
    loc3 = res.x; k3, s3 = weibull_mle(x - loc3)
    k3_sp, l3_sp, s3_sp = stats.weibull_min.fit(x)
    print(f"  3p Weibull (profile): k = {k3:.3f}, loc = {loc3:.1f}, scale = {s3:.1f}, "
          f"logLik {-res.fun:.2f}   [scipy default: k {k3_sp:.3f}, loc {l3_sp:.1f}]")

    models = {
        "Exponential":  (stats.expon,       (0, 1 / lam),      1),
        "Weibull (2p)": (stats.weibull_min, (k_hat, 0, s_hat), 2),
        "Weibull (3p)": (stats.weibull_min, (k3, loc3, s3),    3),
        "Lognormal":    (stats.lognorm,     (ln_s, 0, ln_sc),  2),
        "Gamma":        (stats.gamma,       (g_a, 0, g_sc),    2),
    }
    rows = {}
    for name, (d, a, npar) in models.items():
        ll = np.sum(d.logpdf(x, *a))
        rows[name] = dict(ll=ll, aic=2 * npar - 2 * ll, bic=npar * np.log(n) - 2 * ll)
    best = min(r["aic"] for r in rows.values())
    pos = ["Weibull (2p)", "Weibull (3p)", "Lognormal", "Gamma"]
    wts = {m: np.exp(-(rows[m]["aic"] - min(rows[q]["aic"] for q in pos)) / 2) for m in pos}
    wsum = sum(wts.values())
    print(f"\n  {'Model':<14}{'params':>7}{'logLik':>10}{'AIC':>9}{'dAIC':>8}{'BIC':>9}{'weight*':>9}")
    for name, (d, a, npar) in models.items():
        r = rows[name]
        w = f"{wts[name] / wsum:.3f}" if name in pos else "-"
        print(f"  {name:<14}{npar:>7}{r['ll']:>10.2f}{r['aic']:>9.2f}{r['aic'] - best:>8.2f}{r['bic']:>9.2f}{w:>9}")
    print("  * Akaike weights among the four non-exponential models")

    print(f"\n  {'Model':<14}{'B10 (h)':>9}{'P<500':>10}{'P<900':>9}{'P<1000':>9}{'P<1200':>9}")
    for name, (d, a, npar) in models.items():
        print(f"  {name:<14}{d.ppf(0.10, *a):>9.1f}{d.cdf(500, *a):>10.4%}"
              f"{d.cdf(900, *a):>9.2%}{d.cdf(1000, *a):>9.2%}{d.cdf(1200, *a):>9.2%}")
    print(f"  {'Empirical':<14}{np.percentile(x, 10):>9.1f}{np.mean(x < 500):>10.4%}"
          f"{np.mean(x < 900):>9.2%}{np.mean(x < 1000):>9.2%}{np.mean(x < 1200):>9.2%}")
    print(f"  Empirical counts: <900 h: {int(np.sum(x < 900))} of {n};  <1000 h: {int(np.sum(x < 1000))};  "
          f"<1200 h: {int(np.sum(x < 1200))}")
    print(f"  Binomial SE of an empirical share near 14%: {np.sqrt(0.14 * 0.86 / n):.3f}")

    # like-for-like lower-tail check at 840 h (recorded time 840 = failed in (828, 840))
    print("\n  Lower-tail check: bulbs failed by 840 h (observed: "
          f"{int(np.sum(x <= 840))} of {n})")
    for name in ("Exponential", "Weibull (2p)", "Gamma", "Lognormal"):
        d, a, _ = models[name]
        p = d.cdf(840, *a)
        print(f"   {name:<14} P(<=840) = {p:6.2%}  expected {n * p:5.2f}  "
              f"P(count <= observed) = {stats.binom.cdf(int(np.sum(x <= 840)), n, p):.3g}")

    print("\n  Weibull location profile (loc fixed; k, scale re-fitted)")
    print(f"  {'loc':>6}{'k':>8}{'scale':>9}{'logLik':>10}")
    for loc in (0, 300, 500, 700, 742, 820):
        kk, ss = weibull_mle(x - loc)
        print(f"  {loc:>6}{kk:>8.3f}{ss:>9.1f}{wb_loglik(x, kk, ss, loc):>10.2f}")
    grid = np.arange(0, x.min(), 2.0)
    pl = np.array([-nll_loc(l) for l in grid])
    ok = grid[pl >= pl.max() - stats.chi2.ppf(0.95, 1) / 2]
    ll0 = pl[0]; lrt_loc = 2 * (pl.max() - ll0)
    print(f"  95% profile range for location: [{ok.min():.0f}, {ok.max():.0f}] h;  "
          f"LRT loc = 0 vs best: {lrt_loc:.2f} (p ~ {stats.chi2.sf(lrt_loc, 1):.3f})")

    k_wo, s_wo = weibull_mle(x[x < x.max()])
    print(f"\n  Weibull refit without the {x.max():.0f} h bulb: k = {k_wo:.3f}, scale = {s_wo:.1f}")

    fh = fails["h"].values.astype(float); cnt = fails["f"].values
    def nll_interval(p):
        k_, s_ = np.exp(p)
        pr = stats.weibull_min.cdf(fh, k_, scale=s_) - stats.weibull_min.cdf(fh - 12, k_, scale=s_)
        return -np.sum(cnt * np.log(np.clip(pr, 1e-300, None)))
    r2 = optimize.minimize(nll_interval, [np.log(4.0), np.log(1500.0)], method="Nelder-Mead",
                           options=dict(xatol=1e-8, fatol=1e-10, maxiter=5000))
    k_ic, s_ic = np.exp(r2.x)
    print(f"  Interval-censored Weibull (12 h grid): k = {k_ic:.3f}, scale = {s_ic:.1f}, "
          f"B10 = {stats.weibull_min.ppf(0.10, k_ic, scale=s_ic):.1f} h")

    # figure: CDFs of the four models + lower-tail zoom
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.8))
    tg = np.linspace(300, 2700, 800)
    styles = {"Weibull (2p)": "r-", "Weibull (3p)": "m--", "Lognormal": "g-.", "Gamma": "b:"}
    axs[0].step(xs_sorted, ecdf, where="post", color="black", lw=1.5, label="Empirical")
    for m in pos:
        d, a, _ = models[m]
        axs[0].plot(tg, d.cdf(tg, *a), styles[m], label=m)
        axs[1].semilogy(np.linspace(300, 1000, 400), d.cdf(np.linspace(300, 1000, 400), *a),
                        styles[m], label=m)
    axs[1].axvline(x.min(), color="black", lw=1)
    axs[1].text(x.min() + 8, 2e-5, "first failure\n(840 h)", fontsize=8)
    axs[1].axvline(500, color="grey", ls="--", lw=1)
    axs[1].text(506, 2e-6, "500 h", fontsize=8, color="grey")
    axs[0].set_title("Inside the data the models agree"); axs[0].set_xlabel("Hours")
    axs[0].set_ylabel("P(failed by t)"); axs[0].legend(fontsize=8)
    axs[1].set_title("In the lower tail they diverge (log scale)"); axs[1].set_xlabel("Hours")
    axs[1].set_ylim(1e-6, 0.3)
    save_fig(fig, outdir, "fig5_models.png")

    # figure: hazards
    th = np.linspace(300, 2600, 600)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(th, weibull_hazard(th, k_hat, s_hat) * 1e3, "r-", label="Weibull")
    d, a, _ = models["Gamma"];     ax.plot(th, d.pdf(th, *a) / d.sf(th, *a) * 1e3, "b:", label="Gamma")
    d, a, _ = models["Lognormal"]; ax.plot(th, d.pdf(th, *a) / d.sf(th, *a) * 1e3, "g-.", label="Lognormal")
    ax.axhline(lam * 1e3, color="black", ls="--", label="Exponential (constant)")
    ax.axvspan(x.min(), x.max(), color="grey", alpha=0.12, label="Observed range")
    ax.set_ylim(0, 8); ax.set_xlabel("Bulb age (hours)"); ax.set_ylabel("Failure rate per 1,000 h")
    ax.set_title("Failure risk by age: constant vs rising"); ax.legend()
    save_fig(fig, outdir, "fig3_hazard.png")

    # ==================================================================
    # 6. Simulation: from parameters to returns
    # ==================================================================
    print("\n--- 6. Simulation ---")
    N = 100000
    sim_fixed = stats.weibull_min.rvs(k_hat, scale=s_hat, size=N, random_state=rng)
    idx = rng.integers(0, n_boot, size=N)
    u = rng.uniform(size=N)
    sim_two = bs[idx] * (-np.log(u)) ** (1.0 / bk[idx])
    for label, sim in (("fixed parameters", sim_fixed), ("two-stage (parameter uncertainty)", sim_two)):
        pl_, ph_ = np.percentile(sim, [2.5, 97.5])
        print(f"  {label:<36} P(<{WARRANTY_H}) = {np.mean(sim < WARRANTY_H):.2%}  "
              f"P(<{CHECK_H}) = {np.mean(sim < CHECK_H):.2%}  95% range [{pl_:.0f}, {ph_:.0f}] h")
    print(f"  Exact Weibull P(<{WARRANTY_H}) = {stats.weibull_min.cdf(WARRANTY_H, k_hat, scale=s_hat):.2%} "
          f"(simulation SE ~ {np.sqrt(0.09 * 0.91 / N):.2%})")
    B = 20000
    p_fix = stats.weibull_min.cdf(WARRANTY_H, k_hat, scale=s_hat)
    ret_fix = rng.binomial(BATCH, p_fix, size=B) / BATCH
    p_j = p_w_boot[WARRANTY_H][rng.integers(0, n_boot, size=B)]
    ret_two = rng.binomial(BATCH, p_j) / BATCH
    for label, r in (("fixed parameters", ret_fix), ("with parameter uncertainty", ret_two)):
        lo, med, hi = np.percentile(r, [2.5, 50, 97.5])
        print(f"  Returns per {BATCH:,} bulbs at {WARRANTY_H} h warranty, {label}: "
              f"median {med:.2%}, 95% range [{lo:.2%}, {hi:.2%}]")

    print("\n" + line + "\nANALYSIS COMPLETE\n" + line)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Bulb lifespan analysis")
    ap.add_argument("--data", default=None, help="Path to local lamps.csv")
    ap.add_argument("--outdir", default="output/figures", help="Directory for figures")
    a = ap.parse_args()
    main(a.data, a.outdir)